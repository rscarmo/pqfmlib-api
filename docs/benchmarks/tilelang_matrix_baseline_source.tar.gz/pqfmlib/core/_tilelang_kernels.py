"""FP32/FP64 CUDA kernels. Import only when the optional TileLang engine is selected."""

import tilelang
import tilelang.language as T


@tilelang.jit(target="cuda", execution_backend="tvm_ffi")
def apply_gate(size: int, width: int, dtype: str = "float64"):
    dimension = 1 << width

    @T.prim_func
    def kernel(state: T.Tensor((size, 2), dtype),
               matrix: T.Tensor((dimension, dimension, 2), dtype),
               output: T.Tensor((size, 2), dtype), q0: T.int32, q1: T.int32):
        with T.Kernel(T.ceildiv(size, 128), threads=128) as block:
            i = T.cast(block * 128 + T.get_thread_binding(), "int64")
            if i < size:
                row = (i >> q0) & 1
                if width == 2:
                    row += 2 * ((i >> q1) & 1)
                real = T.alloc_local((1,), dtype)
                imag = T.alloc_local((1,), dtype)
                real[0], imag[0] = 0.0, 0.0
                for column in T.serial(dimension):
                    source = (i & ~(T.int64(1) << q0)) | ((column & 1) << q0)
                    if width == 2:
                        source = (source & ~(T.int64(1) << q1)) | (((column >> 1) & 1) << q1)
                    ar, ai = state[source, 0], state[source, 1]
                    mr, mi = matrix[row, column, 0], matrix[row, column, 1]
                    real[0] += mr * ar - mi * ai
                    imag[0] += mr * ai + mi * ar
                output[i, 0], output[i, 1] = real[0], imag[0]
    return kernel


@tilelang.jit(target="cuda", execution_backend="tvm_ffi")
def apply_batched_gate(size: int, batch: int, width: int, dtype: str = "float64"):
    dimension = 1 << width

    @T.prim_func
    def kernel(state: T.Tensor((batch, size, 2), dtype),
               matrix: T.Tensor((batch, 4, 4, 2), dtype),
               output: T.Tensor((batch, size, 2), dtype), q0: T.int32, q1: T.int32):
        with T.Kernel(T.ceildiv(size, 128), batch, threads=128) as (block, b):
            i = T.cast(block * 128 + T.get_thread_binding(), "int64")
            if i < size:
                row = (i >> q0) & 1
                if width == 2:
                    row += 2 * ((i >> q1) & 1)
                real = T.alloc_local((1,), dtype)
                imag = T.alloc_local((1,), dtype)
                real[0], imag[0] = 0.0, 0.0
                for column in T.serial(dimension):
                    source = (i & ~(T.int64(1) << q0)) | ((column & 1) << q0)
                    if width == 2:
                        source = (source & ~(T.int64(1) << q1)) | (((column >> 1) & 1) << q1)
                    ar, ai = state[b, source, 0], state[b, source, 1]
                    mr, mi = matrix[b, row, column, 0], matrix[b, row, column, 1]
                    real[0] += mr * ar - mi * ai
                    imag[0] += mr * ai + mi * ar
                output[b, i, 0], output[b, i, 1] = real[0], imag[0]
    return kernel


@tilelang.jit(target="cuda", execution_backend="tvm_ffi")
def pauli_partials(size: int, qubits: int, batch: int, terms: int, dtype: str = "float64"):
    tiles = T.ceildiv(size, 128)

    @T.prim_func
    def kernel(state: T.Tensor((batch, size, 2), dtype),
               masks: T.Tensor((terms, 3), "int64"),
               output: T.Tensor((terms, batch, tiles), "float64")):
        with T.Kernel(tiles, terms, batch, threads=128) as (block, term, b):
            values = T.alloc_fragment((128,), "float64")
            reduced = T.alloc_fragment((1,), "float64")
            for lane in T.Parallel(128):
                i = T.cast(block * 128 + lane, "int64")
                values[lane] = 0.0
                if i < size:
                    x, z, phase = masks[term, 0], masks[term, 1], masks[term, 2]
                    j = i ^ x
                    real = T.cast(state[b, j, 0], "float64") * T.cast(state[b, i, 0], "float64") + T.cast(state[b, j, 1], "float64") * T.cast(state[b, i, 1], "float64")
                    imag = T.cast(state[b, j, 0], "float64") * T.cast(state[b, i, 1], "float64") - T.cast(state[b, j, 1], "float64") * T.cast(state[b, i, 0], "float64")
                    parity = T.alloc_local((1,), "int32")
                    parity[0] = 0
                    for bit in T.serial(qubits):
                        parity[0] = parity[0] ^ T.cast(((i & z) >> bit) & 1, "int32")
                    value = T.alloc_local((1,), "float64")
                    if phase == 0:
                        value[0] = real
                    elif phase == 1:
                        value[0] = -imag
                    elif phase == 2:
                        value[0] = -real
                    else:
                        value[0] = imag
                    values[lane] = T.if_then_else(parity[0] == 0, value[0], -value[0])
            T.reduce_sum(values, reduced, dim=0)
            output[term, b, block] = reduced[0]
    return kernel


@tilelang.jit(target="cuda", execution_backend="tvm_ffi")
def pauli_contributions(size: int, qubits: int, dtype: str = "float64"):
    @T.prim_func
    def kernel(state: T.Tensor((size, 2), dtype),
               output: T.Tensor((size,), "float64"),
               x_mask: T.int64, z_mask: T.int64, phase: T.int32):
        with T.Kernel(T.ceildiv(size, 128), threads=128) as block:
            i = T.cast(block * 128 + T.get_thread_binding(), "int64")
            if i < size:
                j = i ^ x_mask
                real = T.cast(state[j, 0], "float64") * T.cast(state[i, 0], "float64") + T.cast(state[j, 1], "float64") * T.cast(state[i, 1], "float64")
                imag = T.cast(state[j, 0], "float64") * T.cast(state[i, 1], "float64") - T.cast(state[j, 1], "float64") * T.cast(state[i, 0], "float64")
                parity = T.alloc_local((1,), "int32")
                parity[0] = 0
                for bit in T.serial(qubits):
                    parity[0] = parity[0] ^ T.cast(((i & z_mask) >> bit) & 1, "int32")
                value = T.alloc_local((1,), "float64")
                if phase == 0:
                    value[0] = real
                elif phase == 1:
                    value[0] = -imag
                elif phase == 2:
                    value[0] = -real
                else:
                    value[0] = imag
                output[i] = T.if_then_else(parity[0] == 0, value[0], -value[0])
    return kernel


@tilelang.jit(target="cuda", execution_backend="tvm_ffi")
def born_probabilities(size: int, batch: int, dtype: str = "float64"):
    @T.prim_func
    def kernel(state: T.Tensor((batch, size, 2), dtype),
               output: T.Tensor((batch, size), "float64")):
        with T.Kernel(T.ceildiv(size, 128), batch, threads=128) as (block, b):
            i = T.cast(block, "int64") * 128 + T.get_thread_binding()
            if i < size:
                real = T.cast(state[b, i, 0], "float64")
                imag = T.cast(state[b, i, 1], "float64")
                output[b, i] = real * real + imag * imag
    return kernel


@tilelang.jit(target="cuda", execution_backend="tvm_ffi")
def sampled_pauli_partials(shots: int, qubits: int, batch: int, terms: int):
    tiles = T.ceildiv(shots, 128)

    @T.prim_func
    def kernel(samples: T.Tensor((batch, shots), "int64"),
               supports: T.Tensor((terms,), "int64"),
               output: T.Tensor((terms, batch, tiles), "int32")):
        with T.Kernel(tiles, terms, batch, threads=128) as (block, term, b):
            values = T.alloc_fragment((128,), "int32")
            reduced = T.alloc_fragment((1,), "int32")
            for lane in T.Parallel(128):
                index = block * 128 + lane
                values[lane] = 0
                if index < shots:
                    bits = samples[b, index] & supports[term]
                    parity = T.alloc_local((1,), "int32")
                    parity[0] = 0
                    for bit in T.serial(qubits):
                        parity[0] = parity[0] ^ T.cast((bits >> bit) & 1, "int32")
                    values[lane] = 1 - 2 * parity[0]
            T.reduce_sum(values, reduced, dim=0)
            output[term, b, block] = reduced[0]
    return kernel
